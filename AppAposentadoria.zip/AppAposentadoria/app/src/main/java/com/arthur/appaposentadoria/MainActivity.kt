package com.arthur.appaposentadoria


import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var etNome: EditText
    lateinit var etIdade: EditText
    lateinit var spinnerGenero: Spinner
    lateinit var btnCalcular: Button
    lateinit var tvResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNome = findViewById(R.id.etNome)
        etIdade = findViewById(R.id.etIdade)
        spinnerGenero = findViewById(R.id.spinnerGenero)
        btnCalcular = findViewById(R.id.btnCalcular)
        tvResultado = findViewById(R.id.tvResultado)

        val generos = arrayOf("Masculino", "Feminino")
        spinnerGenero.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, generos)

        btnCalcular.setOnClickListener {
            calcularAposentadoria()
        }
        val btnGrupo = findViewById<Button>(R.id.btnIrParticipantes)


        btnGrupo.setOnClickListener {
            val intent = Intent(this, SegundaAcitivity::class.java)
            startActivity(intent)
        }
    }

    private fun calcularAposentadoria() {
        val nome = etNome.text.toString()
        val idadeStr = etIdade.text.toString()
        val genero = spinnerGenero.selectedItem.toString()

        if (nome.isEmpty() || idadeStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        val idade = idadeStr.toIntOrNull()
        if (idade == null || idade < 0) {
            Toast.makeText(this, "Idade inválida", Toast.LENGTH_SHORT).show()
            return
        }

        val idadeAposentadoria = if (genero == "Feminino") 60 else 65
        val anosRestantes = idadeAposentadoria - idade

        val resultado = if (anosRestantes <= 0) {
            "$nome, você já pode se aposentar!"
        } else {
            "$nome, faltam $anosRestantes anos para sua aposentadoria."
        }

        tvResultado.text = resultado
    }
}
