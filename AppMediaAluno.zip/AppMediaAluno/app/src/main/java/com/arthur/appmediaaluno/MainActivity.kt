package com.arthur.appmediaaluno

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nota1 = findViewById<EditText>(R.id.nota1)
        val nota2 = findViewById<EditText>(R.id.nota2)
        val nota3 = findViewById<EditText>(R.id.nota3)
        val calcular = findViewById<Button>(R.id.calcular)
        val resultadoM = findViewById<TextView>(R.id.resultadoM)
        val resultadoS = findViewById<TextView>(R.id.resultadoS)


        calcular.setOnClickListener{
            val n1 = nota1.text.toString().toFloatOrNull() ?: 0f
            val n2 = nota2.text.toString().toFloatOrNull() ?: 0f
            val n3 = nota3.text.toString().toFloatOrNull() ?: 0f

            val media = (n1 + n2 + n3) / 3
            val situacao = when {
                media < 4 -> {
                    "Reprovado"
                }
                media >= 4 && media < 6 -> {
                    "Prova Sub"
                }
                else -> {
                    "Aprovado"
                }
            }

            resultadoM.text = "Média: %.2f".format(media)
            resultadoS.text = "Situação:$situacao"
        }
        val btnGrupo = findViewById<Button>(R.id.btnIrParticipantes)


        btnGrupo.setOnClickListener {
            val intent = Intent(this, SegundaActivity::class.java)
            startActivity(intent)
        }
    }
    }

