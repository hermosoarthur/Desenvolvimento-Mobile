package com.arthur.appimc

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etPeso = findViewById<EditText>(R.id.etPeso)
        val etAltura = findViewById<EditText>(R.id.etAltura)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)
        val imgTelaInicial = findViewById<ImageView>(R.id.tela_inicial)
        val imgTabelaIMC = findViewById<ImageView>(R.id.tabela_imc)

        btnCalcular.setOnClickListener(View.OnClickListener {
            val peso = etPeso.text.toString().toDoubleOrNull()
            val altura = etAltura.text.toString().toDoubleOrNull()

            if (peso != null && altura != null && altura > 0) {
                val imc = peso / (altura * altura)
                tvResultado.text = "Seu IMC é: %.2f".format(imc)
            } else {
                tvResultado.text = "Por favor, insira valores válidos."
            }
        })
    }
}
